# Evaluation source provenance

The benchmark manifests record exact source, POM, dependency and protocol hashes.
A Git commit alone is insufficient for runs made with working-tree changes.
`raw/source-snapshots/index.json` maps each selected manifest entry to recovered
source bytes and either a Git revision or the current checkout. The snapshot
path includes its SHA-256. Source recovery is performed by the SDK's
`tools/release/archive_evaluation_sources.py`; hashes must match before acceptance.

The original success sweep's executable sources and POM are recoverable from
local Git history. Later signing, retry-buffer and fault-observation configurations
are distinct datasets. None are pooled. Historical evaluation dependency versions
remain in their manifests; the September 7 transport update is a new configuration.

One intermediate `BenchmarkMain.java` used for the original AWS buffered-retry
success supplement was not committed verbatim. It was recovered by undoing only
the subsequent move of the fixture fault reset from before visibility inspection
to after inspection. Its bytes match the SHA-256 recorded before that experiment.
The recovered file is archived as a hash-verified reconstruction, not represented
as a historical Git commit. The final source keeps faults active through inspection.

Some intermediate reproduction README drafts were untracked and have since
changed. Their original hashes remain in the manifests and the index explicitly
records their missing bytes. They are documentation, not executable inputs.
Every selected executable source and POM must be recovered; a missing executable
input fails the source-archiving command. Diagnostic datasets remain excluded and
do not receive this stronger source-recovery claim.

To reconstruct an earlier evaluation, use a separate SDK checkout with the
original baseline commit available, overlay that evaluation's files using
`original_path` and `snapshot` from the index, verify their hashes, and build with
its archived POM/JDK/requirements and scenario settings. Historical vulnerable
transport versions are evidence identities, not recommended production pins.
Use current source and dependencies for ordinary reproduction. Quantitative
results will vary with host load, runtime and service behavior.
