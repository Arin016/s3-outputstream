# Local S3 engineering evidence

No real-S3 traffic or production object data. Benchmark content was generated.
Full original and corrected runs are retained; consult BENCHMARK_REGISTRY.csv
for inclusion/exclusion rules. Machine home paths and loopback ports are redacted;
index entries distinguish canonical and bundled hashes. Source hashes are unchanged.
Use the SDK tools/benchmarks/analyze.py with the selected raw directories to
regenerate tables. Compilation, source and dependency identities are in manifests.
This archive is a local review artifact, not a release/publication receipt.
