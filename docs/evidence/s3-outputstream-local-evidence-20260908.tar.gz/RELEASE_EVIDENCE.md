# Local candidate and release evidence

Status assembled September 8, 2026. Local candidate only; public distribution and
article publication have not occurred. Final writing is pending Arin's model switch.

## Tested identity

- Branch: `feat/reliability-benchmarks`; version: `2.0.0-SNAPSHOT`.
- Baseline: `939f2bd4350963e9d1486c1abd392ba9e10655b8`.
- Production code/build checkpoint: `8f41160842e144653bc5b5d4838eeb9d5e6c785c`.
- POM SHA-256: `66437b69534673edbef413af5635712881f902013787db0681385bf7454cfd05`.
- AWS SDK 2.47.3; Netty 4.1.137.Final; HttpClient 5.6.3; HttpCore 5.4.3.

The September 7 clean matrix began at `1bf8fc7` with the transport POM uncommitted;
`matrix.json` records its exact source/POM hashes. The tested POM was committed as
`8f41160`. Current main/test source bytes and POM match that matrix. Subsequent
evidence/documentation changes leave those inputs intact.

## Local verification

| Check | Evidence | Result |
|---|---|---|
| Original baseline | `raw/baseline-939f2bd-20260905.txt`, environment and manifest | 20 passing original unit tests |
| Defect reproduced before fix | `raw/producer-regression-red.txt`; `cc5fe5a` | Two RED producer-failure regressions |
| Java 11 | `raw/patched-java-matrix-20260907/java11/` | 75 unit + 16 local integration invocations; no failures/errors/skips |
| Java 17 | `raw/patched-java-matrix-20260907/java17/` | 75 unit + 16 local integration invocations; no failures/errors/skips |
| Java 21 | `raw/patched-java-matrix-20260907/java21/` | 75 unit + 16 local integration invocations; no failures/errors/skips |
| State/limit coverage | Unit XML and source snapshots | Generated operation sequences, fault positions and 10,000/10,001 guard |
| Fixture behavior | Integration XML/logs | Boundaries, hashes/properties, producer/storage faults, retry replay, abort failure/orphans, lost completion response and 128 MiB generated upload |
| Javadocs and packaging | Per-JDK `package-inspection.json` | Strict doclint; binary/source/Javadoc JARs; binary major 55; license/notice; no test/benchmark payload |
| ZIP example | `raw/example-compilation.json` | Compiled under Java 11/17/21; example source unchanged |
| Historical comparison | Registry, raw datasets, `analysis/` | Six adapters; unsuccessful rows retained; supplements separate |
| Patched transport comparison | `analysis/patched-transports/REPORT.md` | 42 six-adapter + 14 buffered AWS success rows, all hash-correct; 21 AWS fault rows, no timeout |
| Source provenance | `raw/source-snapshots/index.json` | Every selected executable/POM input recovered by hash; missing intermediate README drafts explicitly recorded |

The revised CI workflow is configured for Java 11/17/21 and the pinned fixture;
it has not run remotely in this task. Moto 5.1.12 is not real S3. No cloud test
was authorized or run; its manual program remains explicitly gated.

## Package hashes from the patched matrix

| JDK | Binary SHA-256 | Javadoc SHA-256 |
|---|---|---|
| 11 | `4d783ddb33daedd4c3476c76b23f6fd8eddb414e3e1ce6e8028763eabd49c6e7` | `9523af205ca7e3dc27b67d549d0fd84910ed82bccd8480d1e2d22dfd0ac49bf3` |
| 17 | `c74b378859fd25f27b881d69d61987aa4b51e6cfd102def7334df43ad6dae569` | `0eef3412739156853afc362cc0f051a1640207427253bb57748ac300739349bb` |
| 21 | `2e9509f1f7fa763abfa3a902dc184ec2f227b7318cbfaf597aff3671c0221671` | `822250f848d1bca25d29e421153825a36860f2d1f4973eeee001d889048ed49e` |

Sources JAR: `e4e90787b529b1a2fd220e17a2fa4feec4629aac65de99e3179dd216acd39599`
on all three JDKs. Authoritative hashes/sizes are the per-JDK inspection records.
Fixed timestamps do not imply identical binaries/Javadocs across JDKs. Compiled
JARs stay local; the review bundle contains their inspection records.

## Dependency review

The September 6 OSV lookup found advisory matches in historical transport versions;
raw records remain in `raw/dependency-osv-20260906.json` and
`raw/dependency-advisory-details-20260906.json`. Matches do not establish that
every affected server-side feature is reachable through this S3 client.

The September 7 patched lookup returned no advisory matches for 60 comparison-
classpath Maven packages, including provided SDK and test/benchmark dependencies.
See `raw/dependency-osv-patched-20260907.json`. This is a dated database observation,
not proof of security or an audit of a consumer's application. The client is
`provided`; consumers own and must review their dependency configuration.

Primary references: [Netty 4.1.137.Final](https://netty.io/news/2026/08/06/4-1-137-Final.html),
[HttpClient 5.6.3](https://github.com/apache/httpcomponents-client/releases/tag/rel/v5.6.3),
[HttpCore 5.4.3 source](https://hc.apache.org/httpcomponents-core-5.4.x/current/scm.html).
The earlier automatic approval-review usage-limit failure was resolved September
7: dependency resolution, the matrix and advisory query completed. There is no
remaining dependency-validation approval block.

## Remaining distribution steps

Technical local validation is complete. Final article writing and Arin's technical/
authorship review remain. Public action requires explicit authorization for the
reviewed result. Before release, establish namespace ownership
(`io.github.arinmallanna` differs from repository owner `Arin016`), choose a version,
configure publisher credentials/signing outside Git and verify current Central
requirements. Ordinary verification does not deploy, sign or publish. Optional
real-S3 evaluation needs separate authorization and a dedicated disposable prefix.

User `BLOG.md` remains untracked and byte-identical to its baseline hash
`e216f224e4a6a2d0548b455d6b978e5ed0d01833c67872df060f97c3de1e294f`.
The separate site is untouched by this task and clean at
`ca21e08c410f69ee0cfa631bad1ea3925667bf0c`; its advancement from `d8f3d69` was independent.
Its S3 article hash remains
`2fc3783ae47d371d3bf53a0b357cfe34ab1cd2feb981b9aea7f8e4775578276b`.
