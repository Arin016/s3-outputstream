# Post-update transport checks

Collected September 7, 2026 on the same Corretto 21/macOS/Moto configuration. AWS SDK 2.47.3; Netty 4.1.137.Final; HttpClient 5.6.3; HttpCore 5.4.3.
These are separate validation datasets. Do not pool with or silently replace September 6 measurements. Each success block has two warmups and five measurements; every row passed length/SHA-256 verification.

| Case | Adapter | Correct / measured | Seconds, median [Q1, Q3] | MiB/s | Peak used heap MiB | Peak RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| 128m-unknown | whole-buffer | 5/5 | 0.44 [0.44, 0.45] | 288.70 [286.06, 289.82] | 205.38 [205.37, 205.38] | 453.23 [453.09, 453.31] |
| 128m-unknown | temp-file | 5/5 | 1.06 [1.04, 1.10] | 120.53 [116.30, 122.51] | 12.42 [12.41, 12.42] | 184.14 [184.09, 184.20] |
| 128m-unknown | aws-async | 5/5 | 0.34 [0.33, 0.35] | 377.57 [365.62, 391.53] | 91.92 [91.49, 92.70] | 298.38 [297.14, 298.72] |
| 128m-unknown | ci-cmg | 5/5 | 0.45 [0.43, 0.46] | 284.02 [275.27, 295.99] | 60.70 [60.69, 60.71] | 238.66 [238.22, 239.94] |
| 128m-unknown | original-939f2bd | 5/5 | 0.61 [0.60, 0.61] | 208.96 [208.55, 211.82] | 54.74 [54.73, 54.74] | 233.58 [233.08, 234.14] |
| 128m-unknown | improved | 5/5 | 0.60 [0.59, 0.61] | 214.47 [210.81, 217.31] | 21.56 [21.55, 21.57] | 190.92 [190.41, 191.48] |

## AWS buffered retry option

| Case | Adapter | Correct / measured | Seconds, median [Q1, Q3] | MiB/s | Peak used heap MiB | Peak RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| 128m-unknown | aws-async | 5/5 | 0.36 [0.33, 0.38] | 358.88 [340.89, 385.83] | 143.18 [138.20, 154.67] | 352.27 [351.41, 357.20] |
| 128m-known | aws-async | 5/5 | 0.28 [0.27, 0.28] | 460.01 [458.84, 467.43] | 87.05 [86.86, 87.82] | 276.88 [276.00, 277.22] |

## Buffered retry fault outcomes

| Case | Forks | Timeouts | Full / partial / absent objects | Orphan uploads |
|---|---:|---:|---:|---:|
| complete-failure | 3 | 0 | 0 / 0 / 3 | 0 |
| create-failure | 3 | 0 | 0 / 0 / 3 | 0 |
| part-and-abort-failure | 3 | 0 | 0 / 0 / 3 | 3 |
| permanent-part | 3 | 0 | 0 / 0 / 3 | 0 |
| producer-after-multipart | 3 | 0 | 0 / 0 / 3 | 0 |
| producer-before-multipart | 3 | 0 | 0 / 0 / 3 | 0 |
| transient-part | 3 | 0 | 3 / 0 / 0 | 0 |

Faults remained active through inspection. All 21 completed rows verified administrative harness cleanup. Three part-plus-abort failures left one orphan each before that cleanup; this is not adapter cleanup success.

Peak heap/RSS are sampled lower bounds. RSS excludes the service. Medians and inclusive quartiles describe one JVM block per success case, not independent host replications.
